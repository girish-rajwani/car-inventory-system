<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Manufacturer extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'manufacturer_details';
	
	protected $fillable = [
        'manufacturer_name',
    ];
	public $timestamps = false;

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
  
}
