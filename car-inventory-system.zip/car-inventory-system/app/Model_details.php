<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Model_details extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'model_details';
	
	protected $fillable = [
        'model_name','manufacturer_id','model_color','reg_number','manufacturing_year','note','count','images'
    ];
	public $timestamps = false;

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
  
}
