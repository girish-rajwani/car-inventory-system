<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Validation\Validator;
use App\Model_details;
use App\Manufacturer;

class Car_controller extends Controller {
	
	public function model_create() {
		$manufacturer_details = Manufacturer::all()->toArray();
		if(empty($manufacturer_details))
		{
			$manufacturer_details = array();
		}
		return view('model_create',[ 'manufacturer_details' => $manufacturer_details ]);
   }

	public function manufacturer_create() {
      return view('manufacturer_create');
   }

	public function car_details() {
      return view('car_details');
   }
   
   public function model_details() {
		$manufacturer_details = Manufacturer::all()->toArray();
		return view('model_details',[ 'manufacturer_details' => $manufacturer_details ]);
   }
   
	public function manufacturer_details() {
		return view('manufacturer_details');
	}
	
	public function insert_model(Request $request) {
		//dd($request->all());
		$data['model_name'] = $request->input('model_name');
		$data['manufacturer_id'] = $request->input('manufacturer_name');
		$data['model_color'] = $request->input('color');
		$data['manufacturing_year'] = $request->input('manufacturing_year');
		$data['reg_number'] = $request->input('reg_number');
		$data['note'] = $request->input('note');
		$data['count'] = $request->input('count');
		$this->validate($request, [
			'filename' => 'required',
			'filename.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
		]);
		if($request->hasfile('filename'))
		{	
			$file_names = array();
			foreach($request->file('filename') as $image)
			{
				$name=$image->getClientOriginalName();
				$image->move(public_path().'/images/', $name);  
				$file_names[] = $name;  
			}
			$data['images'] = json_encode($file_names);							
		}
		Model_details::create($data);
		$notification['message'] 	= "Model Saved Successfully";
		$notification['alert-type'] = "success";
		return redirect()->route('car-details')->with('notification', $notification);
   }
   
   public function insert_manufacturer(Request $request) {
		$data['manufacturer_name'] = $request->	input('manufacturer_name');
		Manufacturer::updateOrCreate($data);
		$notification['message'] 	= "Manufacturer Saved Successfully";
		$notification['alert-type'] = "success";
		return redirect()->route('car-details')->with('notification', $notification);
   }
   
	public function delete_model(Request $request, $id) {
		$data = Manufacturer::find($id);
		$data->delete();
		$notification['message'] 	= "Solded Successfully";
		$notification['alert-type'] = "success";
		return redirect()->route('car-details')->with('notification', $notification);
	}
	/* 
	public function save_demo(Request $request)
	{		
		$this->validate($request, [
			'filename' => 'required',
			'filename.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048'
		]);
		if($request->hasfile('filename'))
		{
			foreach($request->file('filename') as $image)
			{
				$name=$image->getClientOriginalName();
				$image->move(public_path().'/images/', $name);  
				$data[] = $name;  
			}
		}
		
	} */

	public function get_single_model_data(Request $request)
	{
		$id = $request->input('id');
		//$data = Model_details::where('id', $id)->get();
		$data = Model_details::Join('manufacturer_details', 'model_details.manufacturer_id', '=', 'manufacturer_details.id')
		->where('model_details.id', $id)
		->select('model_details.*', 'manufacturer_details.manufacturer_name')
		->get();
		echo json_encode($data);
	}

	public function get_model_data(Request $request)
	{
		//if($request->ajax()) 
		{
			$columns     = ['id', 'model_name', 'manufacturer_name', 'model_color', 'manufacturing_year', 'reg_number', 'note'];
			$draw        = $request->draw;
			$start       = $request->start; //Start is the offset
			$length      = $request->length; //How many records to show			
			$column      = $request->order[0]['column']; //Column to orderBy			
			$dir         = $request->order[0]['dir']; //Direction of orderBy
			$searchValue = $request->search['value']; //Search value
			
			//Sets the current page
			Paginator::currentPageResolver(function () use ($start, $length) {
				return ($start / $length + 1);
			});
			
			$model = Model_details::Join('manufacturer_details', 'model_details.manufacturer_id', '=', 'manufacturer_details.id')
			->where('model_details.count', '>', 0)
			->select('model_details.*', 'manufacturer_details.manufacturer_name')
			->orderBy($columns[$column], $dir)
			->paginate($length);			
			
			return [
				'draw' => $draw,
				'recordsTotal' => $model->total(),
				'recordsFiltered' => $model->total(),
				'data' => $model
			];
		}
	}

	public function sold_model(Request $request)
	{
		$id = $request->input('id');
		$row = Model_details::find($id)->first();				
		$count = ($row->count) - 1;		
		Model_details::where('id', $id)->update(['count' => $count]);
		$notification['message'] 	= "Model Sold Successfully";
		$notification['alert-type'] = "success";
		return redirect()->route('car-details')->with('notification', $notification);
	}
}