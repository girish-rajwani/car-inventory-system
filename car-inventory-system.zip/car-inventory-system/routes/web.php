<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('car_details');
});
Route::any('car-details', function () {
    return view('car_details');
})->name('car-details');;
Route::any('model-create', 'Car_controller@model_create')->name('model-create');
Route::any('manufacturer-create', function () {
    return view('manufacturer_create');
})->name('manufacturer-create');
Route::any('insert-manufacturer', 'Car_controller@insert_manufacturer')->name('insert-manufacturer');
Route::any('insert-model', 'Car_controller@insert_model')->name('insert-model');
Route::any('save-demo', 'Car_controller@save_demo')->name('save-demo');

Route::any('demo', 'Car_controller@demo')->name('demo');

Route::any('get-model-data', 'Car_controller@get_model_data')->name('get-model-data');

Route::any('get-single-model-data', 'Car_controller@get_single_model_data')->name('get-single-model-data');

Route::any('sold-model', 'Car_controller@sold_model')->name('sold-model');
