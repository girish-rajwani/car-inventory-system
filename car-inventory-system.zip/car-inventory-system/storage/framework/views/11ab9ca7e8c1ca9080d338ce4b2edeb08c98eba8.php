<!doctype html>

<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>New Manufacturer</h2>
  <br>
  <form action="insert-manufacturer" method="post">
	<?php echo csrf_field(); ?>
	<div class="row">
	<div class="form-group col-md-6">
	  <label for="usr">Manufacturer Name:</label>
	  <input type="text" required class="form-control" name="manufacturer_name">
	</div>
	</div>
	<div class="form-group">
		<input type="submit" class="btn btn-info"/>
	</div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>