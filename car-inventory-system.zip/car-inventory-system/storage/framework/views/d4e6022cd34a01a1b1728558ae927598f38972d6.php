<!doctype html>

<?php $__env->startSection('content'); ?>
<link rel='stylesheet' href='https://www.jquery-az.com/boots/style.css'></link>
<link rel='stylesheet' href='https://www.jquery-az.com/boots/css/bootstrap-imageupload/bootstrap-imageupload.css'></link>
<style>
	.imageupload {
		margin: 20px 0;
	}
</style>	
	<div class="container">
		<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Whoops!</strong> There were some problems with your input.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
		<div class="form-group">
		<br>
		<h2>New Manufacturer</h2>
		<br>
		<form action="insert-model" method="post" file="true" enctype="multipart/form-data">
			
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group">
						<label for="usr">Model Name:</label>
						<input type="text" required class="form-control" name="model_name">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="usr">Manufacturer Name:</label>
						<select required class="form-control" name="manufacturer_name">
							<?php if(!empty($manufacturer_details)): ?>
								<option value="">
									Select manufacturer
								</option>
								<?php $__currentLoopData = $manufacturer_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($detail['id']); ?>">
									<?php echo e($detail['manufacturer_name']); ?>

								</option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
								<option value="Please create manufacturer first">
									Please create manufacturer first
								</option>
							<?php endif; ?>	
						</select>						
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6">
					<div class="form-group">
						<label for="usr">Model Color:</label>
						<input type="text" required class="form-control" name="color">
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label for="usr">Manufacturing Year:</label>
						<input type="text" required class="form-control" name="manufacturing_year">
					</div>
				</div>
				<div class="col-sm-4">
					<div class="form-group">
						<label for="usr">Registeration Number:</label>
						<input type="text" required class="form-control" name="reg_number">
					</div>
				</div>
				<div class="col-sm-4">
					<div class="form-group">
						<label for="usr">Count:</label>
						<input type="number" min="0" required class="form-control" name="count"/>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="form-group">
						<label for="usr">Note:</label>
						<textarea class="form-control" name="note"></textarea>
					</div>
				</div>
			</div>
			<div class="row">			
				<div class="col-sm-12">					
					<div class="form-group">	
						<label for="usr">Select 2 pictures:</label> 	
						<div class="imageupload panel panel-default">
							<div class="panel-heading clearfix">
								<h3 class="panel-title pull-left">Select Image file</h3>
								<div class="btn-group pull-right">
									<button type="button" class="btn btn-default active">File</button>
									<button type="button" class="btn btn-default">URL</button>
								</div>
							</div>
							<div class="file-tab panel-body">
								<label class="btn btn-primary btn-file">
									<span>Browse</span>
									<!-- The file is stored here. -->
									<input type="file" name="filename[]">
								</label>
								<button type="button" class="btn btn-danger">Delete image</button>
							</div>
							<div class="url-tab panel-body">
								<div class="input-group">
									<input type="text" class="form-control hasclear" placeholder="Image URL">
									<div class="input-group-btn">
										<button type="button" class="btn btn-default">Submit</button>
									</div>
								</div>
								<button type="button" class="btn btn-default">Remove</button>
								<!-- The URL is stored here. -->
								<input type="hidden" name="image-url"/>
							</div>
						</div>
						<div class="imageupload panel panel-default">
							<div class="panel-heading clearfix">
								<h3 class="panel-title pull-left">Select Image file</h3>
								<div class="btn-group pull-right">
									<button type="button" class="btn btn-default active">File</button>
									<button type="button" class="btn btn-default">URL</button>
								</div>
							</div>
							<div class="file-tab panel-body">
								<label class="btn btn-primary btn-file">
									<span>Browse</span>
									<!-- The file is stored here. -->
									<input type="file" name="filename[]">
								</label>
								<button type="button" class="btn btn-danger">Delete image</button>
							</div>
							<div class="url-tab panel-body">
								<div class="input-group">
									<input type="text" class="form-control hasclear" placeholder="Image URL">
									<div class="input-group-btn">
										<button type="button" class="btn btn-default">Submit</button>
									</div>
								</div>
								<button type="button" class="btn btn-default">Remove</button>
								<!-- The URL is stored here. -->
								<input type="hidden" name="image-url">
							</div>
						</div>
					</div>
				</div>
			</div>
			<script src="https://www.jquery-az.com/boots/js/bootstrap-imageupload/bootstrap-imageupload.js"></script>
			<script>
				var $imageupload = $('.imageupload');
				$imageupload.imageupload({
					maxWidth: 500,
					maxHeight: 500,
					maxFileSizeKb: 3048
				});

			</script>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<div class="form-group text-center">
						<input type="submit" class="btn btn-info"/>
					</div>
				</div>
			</div>
			
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>