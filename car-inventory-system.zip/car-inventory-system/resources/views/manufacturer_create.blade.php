<!doctype html>
@extends('header')
@section('content')
<div class="container">
  <h2>New Manufacturer</h2>
  <br>
  <form action="insert-manufacturer" method="post">
	@csrf
	<div class="row">
	<div class="form-group col-md-6">
	  <label for="usr">Manufacturer Name:</label>
	  <input type="text" required class="form-control" name="manufacturer_name">
	</div>
	</div>
	<div class="form-group">
		<input type="submit" class="btn btn-info"/>
	</div>
  </form>
</div>
@endsection